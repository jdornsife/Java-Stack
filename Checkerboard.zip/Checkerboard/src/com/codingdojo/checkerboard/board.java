package com.codingdojo.checkerboard;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class board
 */
@WebServlet("/board")
public class board extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public board() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
		// get the value for the query parameter
        String width = request.getParameter("w");
        String height = request.getParameter("h");
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        // lets show our values to the browser
        out.write("<style>");
        out.write("board_main: { border: 1px solid black }");
        out.write("board_column_hor: { display: inline-block; padding: 20px; background-color: red; }");
        out.write("board_column_ver: { display: block; padding: 20px; background-color: green; }");
        out.write("</style>");
        
        out.write("<p>");
        out.write("Width: " + width + "<br>");
        out.write("Height: " + height);
        out.write("</p>");
        
        out.write("<div class=\"board_main\">");
        // lets loop through how many cols we need (width parameter)
        // hcolumns = horizontal columns
        for(Integer hcolumns = 0; hcolumns < width; hcolumns++) {
        	out.write("<div class=\"board_column_hor\"></div>");
        }
        // now lets loop through how many rows we need (height parameter)
        for(Integer vcolumns = 0; vcolumns < height; vcolumns++) {
        	out.write("<div class=\"board_column_ver\"></div>");
        }
        out.write("</div>");
        
        }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
